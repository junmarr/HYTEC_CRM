<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php

require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $cName = $_POST["cName"];
    $cNum = $_POST["cNum"];
    $email = $_POST["email"];
    $company = $_POST["company"];
    $clientId = $_POST["clientId"]; // Retrieve contactId if provided
    $status = "";
    $deleted = 0;

    if (!empty($clientId)) {
        // Update operation
        $sql = "UPDATE clients SET cName = ?, cNum = ?, email = ?, company = ? WHERE client_ID = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$cName, $cNum, $email, $company, $clientId]);
        $status = "Data Updated";
    } else {
        // Insert operation
        $sql = "INSERT INTO clients (cName, cNum, email, company, deleted) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$cName, $cNum, $email, $company, $deleted]);
        $status = "Data Added";
    }

    // Redirect back to the page with a success or error message
    if ($stmt->rowCount() > 0) {
        header("Location: client.php?status=". $status ."");
        exit();
    } else {
        header("Location: client.php?status=error");
        exit();
    }
}
?>
