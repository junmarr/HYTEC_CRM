<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php

require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $fName = $_POST["firstName"];
    $lName = $_POST["lastName"];
    $email = $_POST["email"];
    $adminId = $_POST["accId"]; // Retrieve contactId if provided
    $password_hash = 0;
    $status = "";
    $deleted = 0;

    if (!empty($adminId)) {
        // Update operation
        $sql = "UPDATE admin SET email = ?, fName = ?, lName = ? WHERE admin_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$email, $fName, $lName, $adminId]);
        $status = "Data Updated";
    } else {
        // Insert operation
        $sql = "INSERT INTO admin (email, password_hash, fName, lName, deleted) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$email, $password_hash, $fName, $lName, $deleted]);
        $status = "Data Added";
    }

    // Redirect back to the page with a success or error message
    if ($stmt->rowCount() > 0) {
        header("Location: contacts-list-archived.php?status=". $status ."");
        exit();
    } else {
        header("Location: contacts-list-archived.php?status=error");
        exit();
    }
}
?>
