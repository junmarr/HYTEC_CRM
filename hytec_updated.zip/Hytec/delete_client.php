<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['client_id'])) {
    $client_id = $_POST['client_id'];

    // Prepare and execute deletion query
    $sql = "DELETE FROM clients WHERE client_ID = :client_id";
    $stmt = $con->prepare($sql);
    $stmt->bindParam(':client_id', $client_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        // Deletion successful
        header("Location:  contacts-list-archived.php?status=Data fully deleted");
        exit();
    } else {
        // Deletion failed
        header("Location:  contacts-list-archived.php?status=error");
        exit();
    }
} else {
    // Redirect if accessed directly
    header("Location: contacts-list-archived.php");
    exit();
}
?>
