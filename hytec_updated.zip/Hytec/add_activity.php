<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $desc = $_POST["descrip"];
    $aDate = $_POST["datee"];
    $aName = $_POST["actName"];
    $contactId = $_POST["id"];
    $actID = $_POST["act_ID"];

    $aDate = date("Y-m-d", strtotime($_POST["datee"]));

    if (!empty($actID)) {
        // Update operation
        $sql = "UPDATE activity SET actName=?, datee = ?, descrip = ? WHERE act_ID = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$aName, $aDate, $desc, $actID]);
        $status = "Data Updated";
    } else {
        // Insert operation
        $sql = "INSERT INTO activity (actName, datee, descrip, contacts_ID) VALUES (?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$aName, $aDate, $desc, $contactId]);
        $status = "Data Added";
    }
    if ($stmt->rowCount() > 0) {
        header("Location: contact_details.php?id=" . $contactId . "&status=" . $status);
        exit();
    } else {
        header("Location: contact_details.php?status=error");
        exit();
    }
}
?>
