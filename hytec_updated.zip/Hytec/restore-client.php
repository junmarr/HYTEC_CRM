<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
require_once("includes/connect.php");


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['client_id'])) {
    $client_id = $_POST['client_id'];
        // Update operation   
        $sql = "UPDATE clients SET deleted = 0 WHERE client_ID = ?";   
        $stmt = $con->prepare($sql);
        $stmt->execute([$client_id]);
        $status = "Data restored";

        if ($stmt->rowCount() > 0) {
        header("Location: contacts-list-archived.php?status=". $status ."");
        exit();
    } else {
        header("Location: contacts-list-archived.php?status=error");
        exit();
    }
}
?>




