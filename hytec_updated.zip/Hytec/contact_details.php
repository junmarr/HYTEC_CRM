<?php
// include "includes/connect.php";

// $query = "SELECT * FROM contacts WHERE contacts_ID = '$_GET[id]'";
// $data = $con->query($query);
// $row = $data->fetchAll();

include "includes/connect.php";

$contactID = $_GET['id'];

$query = "SELECT * FROM contacts WHERE contacts_ID = :contactID";
$statement = $con->prepare($query);

$statement->bindParam(':contactID', $contactID, PDO::PARAM_INT);

$statement->execute();

$row = $statement->fetch();
?>

<?php
include "includes/connect.php";

$contactID = $_GET['id'];

$query = "SELECT * FROM deals WHERE contacts_ID = :contactID";
$statement = $con->prepare($query);
$statement->bindParam(':contactID', $contactID, PDO::PARAM_INT);
$statement->execute();
$deals = $statement->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/newstyle.css">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS (for icons) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap DateTimePicker CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Moment.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

    <!-- Bootstrap DateTimePicker JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>


    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS (for icons) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap DateTimePicker CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "navbar.php";
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800 d-flex justify-content-between align-items-center">
                        <span>Overview</span>
                        <button type="button" class="btn btn-info btn-add" onclick="window.location.href='contacts.php'">
                            <span class="fas fa-arrow-left"></span> Back
                        </button>
                    </h1>

                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
        For more information about DataTables, please visit the <a target="_blank"
            href="https://datatables.net">official DataTables documentation</a>.</p> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="row">
                            <div class="col-lg-6">

                                <div class="card position-relative">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Contact Details</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if (is_array($row) && count($row) > 0) : ?>
                                                <div class="col-lg-4">
                                                    <div class="small mb-1">Contact ID</div>
                                                    <a class="navbar-brand" href="#" style="color:black"><?php echo $row['contacts_ID']; ?></a>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="small mb-1">First Name</div>
                                                    <a class="navbar-brand" href="#" style="color:black"><?php echo $row['fName']; ?></a>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="small mb-1">Last Name</div>
                                                    <a class="navbar-brand" href="#" style="color:black"><?php echo $row['lName']; ?></a>
                                                </div>
                                            <?php else : ?>
                                                <div class="col-lg-12">
                                                    <p>No data found for the given contact ID.</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <?php if (is_array($row) && count($row) > 0) : ?>
                                                <div class="col-lg-4">
                                                    <div class="small mb-1">Contact Number</div>
                                                    <a class="navbar-brand" href="#" style="color:black"><?php echo $row['cNum']; ?></a>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="small mb-1">Email Address</div>
                                                    <a class="navbar-brand" href="#" style="color:black"><?php echo $row['eMail']; ?></a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-6">

                                <?php
                                $query = "SELECT * FROM activity WHERE contacts_ID = :contactID";
                                $statement = $con->prepare($query);
                                $statement->bindParam(':contactID', $contactID, PDO::PARAM_INT);
                                $statement->execute();
                                $activities = $statement->fetchAll(PDO::FETCH_ASSOC);
                                ?>

                                <div class="card position-relative" style="height: 244px; overflow-y: auto;">
                                    <!-- <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                        <h6 class="m-0 font-weight-bold text-primary"><span>Itinerary</span>

                                            <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#activityModal" data-action="add">
                                                Add <span class="fa fa-plus"></span>
                                            </button>

                                            
                                        </h6>

                                    </div> -->

                                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                        <h6 class="m-0 font-weight-bold text-primary">Itinerary</h6>
                                        <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#activityModal" data-action="add">
                                            Add <span class="fa fa-plus"></span>
                                        </button>
                                        <!-- <label> <span>Search:</span>
                                                <input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable">
                                             </label> -->
                                    </div>

                                    <div class="card-body">

                                        <div class="row">
                                            <?php foreach ($activities as $index => $activity) : ?>
                                                <div class="col-md-6">
                                                    <div class="card mt-2 mb-3" style="max-width: 250px;">
                                                        <div class="card-header">
                                                            <b><?php echo $activity['actName']; ?></b>
                                                        </div>
                                                        <div class="card-body">
                                                            <h6><?php echo $activity['datee']; ?></h6>
                                                            <br>
                                                            <p class="mb-0 medium">Description: <?php echo $activity['descrip']; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>

                                        <!-- Small card inside the existing card -->


                                    </div>
                                </div>



                            </div>
                        </div>


                    </div>

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800">Deals</h1> -->
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="row">
                        </div>
                        <!-- <div class="py-3 justify-content-between align-items-center d-flex" style="margin-left: 10px;">
                <h6 class="m-2 font-weight-bold" style="font-size: 20px;"><?php echo $row['fName'] . ' ' . $row['lName']; ?></h6>
                <div class="ml-auto">
                    <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#contactModal" data-action="add">Add Deal <span class="fa fa-plus"></span></button>
                </div>
            </div> -->

                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <div class="dropdown">
                                <button class="btn btn-link text-primary border-0 bg-transparent dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span>List of Clients</span>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="cursor: pointer;">
                                    <h6 class="m-0 font-weight-bold text-primary dropdown-item" onclick="showCloseButton('Existing', event)">Existing</h6>
                                    <h6 class="m-0 font-weight-bold text-primary dropdown-item" onclick="showCloseButton('In - Negotiation', event)">In - Negotiation</h6>
                                    <!-- Add more clients here if needed -->
                                </div>

                                <button id="closeButton" class="btn  border-0 bg-transparent" type="button" style="display: none;">x</button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="cursor: pointer;">
                                    <h6 class="m-0 font-weight-bold text-primary dropdown-item" onclick="showCloseButton('Existing', event)">Existing</h6>
                                    <h6 class="m-0 font-weight-bold text-primary dropdown-item" onclick="showCloseButton('In - Negotiation', event)">In - Negotiation</h6>
                                    <!-- Add more clients here if needed -->
                                </div>
                            </div>
                            <div>
                                <button type="button" class="btn btn-primary btn-add" data-bs-toggle="modal" data-bs-target="#contactModal" data-action="add">
                                    Add <span class="fa fa-plus"></span>
                                </button>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th style="display: none;">#</th> <!-- This is the ID column -->
                                            <th>Clients Name</th>
                                            <th style="display: none;">Deal Value</th>
                                            <th>Deal Stage</th>
                                            <th style="display: none;">Expected Date</th>
                                            <th>Last Contract Date</th>
                                            <th>cID</th>
                                            <th>Action</th>
                                            <th style="display: none;">Contacts ID</th> <!-- This is the Contacts ID column -->
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th style="display: none;">#</th>
                                            <th>Clients Name</th>
                                            <th style="display: none;">Deal Value</th>
                                            <th>Deal Stage</th>
                                            <th style="display: none;">Expected Date</th>
                                            <th>Last Contract Date</th>
                                            <th>cID</th>
                                            <th>Action</th>
                                            <th style="display: none;">Contacts ID</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php foreach ($deals as $deal) : ?>
                                            <?php if ($deal['isDeleted'] !== 1) : ?>
                                                <tr class="<?php echo strtolower(str_replace(' ', '-', $deal['dStage'])); ?>">
                                                    <td style="display: none;"><?php echo $deal['dealID'] ?></td>
                                                    <td><?php echo $deal['dName'] ?></td>
                                                    <td style="display: none;">><?php echo $deal['dValue'] ?></td>
                                                    <td><?php echo $deal['dStage'] ?></td>
                                                    <td><?php echo $deal['datee'] ?></td>
                                                    <td><?php echo $deal['client_ID'] ?></td>
                                                    <td style="display: none;">><?php echo date("F j, Y", strtotime($deal['datee'])) ?></td>
                                                    <td style="display: none;"><?php echo $deal['contacts_ID'] ?></td>
                                                    <td>

                                                        <!-- <button type='button' class='btn btn-success view-button' data-bs-toggle='modal' data-bs-target="#contactModal<?php echo $row['contacts_ID'] ?>">View Details <i class="fa fa-eye" style=" display:inline"></i></button> -->

                                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#viewDetailsModal">
                                                            View Details <i class="fa fa-eye" style=" display:inline"></i></button>

                                                             <!-- ayaw ma show -->
                                                            <!-- <button type="button" class="btn btn-success view-button" data-bs-toggle="modal" data-bs-target="#viewDetailsModal" data-client-id="<?php echo $deal['client_ID']; ?>">
                                                                View Details <i class="fa fa-eye" style="display:inline"></i>
                                                            </button> -->

                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <!-- <a href="deals.php?id=<?php echo $row['contacts_ID']; ?>" class="btn btn-info">Deals</a> -->
                            </div>
                        </div>
                    </div>
                </div>
                </table>
            </div>

            <div class="modal fade" id="viewDetailsModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <h5 class="modal-title">Deal Details</h5>
                        <!-- <h6 class="m-2 font-weight-bold" style="font-size: 20px;"><?php echo $row['dName'] . ' ' . $row['lName']; ?></h6> -->
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th style="display: none;">#</th> <!-- This is the ID column -->
                                    <th>Orders</th>
                                    <!-- <th>Deal Name</th> -->
                                    <th>Deal Value</th>
                                    <!-- <th>Deal Stage</th> -->
                                    <th>Date of Contract</th>
                                    <th>Deal Stage</th>
                                    <th>Action</th>
                                    <!-- <th>Action</th> -->
                                    <th style="display: none;">Contacts ID</th> <!-- This is the Contacts ID column -->
                                </tr>
                            <tfoot>
                                <tr>
                                    <th style="display: none;">#</th>
                                    <th>Orders</th>
                                    <!-- <th>Deal Name</th> -->
                                    <th>Deal Value</th>
                                    <th>Date of Contract</th>
                                    <th>Deal Stage</th>
                                    <!-- <th>Action</th> -->
                                    <th style="display: none;">Contacts ID</th>
                                </tr>
                            </tfoot>
                            </thead>

                            <tbody>
                                <?php foreach ($deals as $deal) : ?>
                                    <?php if ($deal['isDeleted'] !== 1) : ?>
                                        <tr>
                                            <td style="display: none;"><?php echo $deal['dealID'] ?></td>
                                            <td><?php echo $deal['orders'] ?></td>
                                            <td><?php echo $deal['dValue'] ?></td>
                                            <td><?php echo date("F j, Y", strtotime($deal['datee'])) ?></td>
                                            <!-- <td><?php echo $deal['dName'] ?></td>         -->
                                            <td><?php echo $deal['dStage'] ?></td>
                                            <td style="display: none;"><?php echo $deal['contacts_ID'] ?></td>

                                            <td>

                                                <!-- <button type='button' class='btn btn-dark edit-button' data-bs-toggle='modal' data-bs-target='#contactModal' data-id="<?php echo $deal['dealID']; ?>" data-dname="<?php echo $deal['dName']; ?>" data-dvalue="<?php echo $deal['dValue'] ?>" data-dstage="<?php echo $deal['dStage'] ?>" data-datee="<?php echo $deal['datee'] ?>">Edit <i class="fa fa-edit" style=" display:inline"></i></button>


                                            <button type='button' class='btn btn-danger delete-button' data-bs-toggle='modal' data-bs-target="#deleteModal<?php echo $deal['dealID'] ?>">Delete <i class="fa fa-trash" style=" display:inline"></i></button> -->
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Deal</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="background-color:rgba(255,255,255, .1); border:none"><sup style="font-size:15px">x</sup></button>
                    </div>
                    <div class="modal-body">

                        <form id="contactForm" action="add_deals.php" method="POST">
                            <input type="hidden" id="dealID" name="dealID">
                            <input type="hidden" id="contactId" name="id" value="<?php echo $contactID; ?>">
                            <div class="mb-3">
                                <label for="DealName" class="form-label">Deal Name</label>
                                <input type="text" class="form-control" id="DealName" name="dealName" required>
                            </div>

                            <div class="mb-3">
                                <label for="DealValue" class="form-label">Deal Value</label>
                                <input type="number" class="form-control" id="DealValue" name="dealValue" required>
                            </div>

                            <div>
                                <label for="DealStage" class="form-label">Deal Stage</label>
                                <div class="mb-3 custom-dropdown input-group">
                                    <input type="text" class="form-control dropdown-input" id="dealStage" name="dealStage" placeholder="Click to select">
                                    <div class="input-group-append">
                                        <span class="input-group-text dropdown-icon"><i class="drop-icon fas fa-caret-down"></i></span>
                                    </div>
                                    <ul class="dropdown-list">
                                        <li>Existing</li>
                                        <li>In - Negotiation</li> <!-- Corrected typo -->
                                        <!-- Add more options as needed -->
                                    </ul>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="datetimepicker" class="form-label">Select Date and Time:</label>
                                <div class="input-group date" id="datetimepicker" name="datetimepicker" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" id="datetimepicker" name="dDate" data-target="#datetimepicker" placeholder="Select Date and Time" />

                                    <div class="input-group-append" data-target="#datetimepicker" data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="cont" class="form-label">Contact No.</label>
                                <input type="text" class="form-control" id="contacts" name="contacts" required>
                            </div>

                            <div class="mb-3">
                                <label for="orders" class="form-label">Orders</label>
                                <input type="text" class="form-control" id="orders" name="orders" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>

                    </div>

                </div>
            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="activityModal" tabindex="-1" aria-labelledby="activityModalLabel" aria-hidden="true">
            <!-- Modal dialog -->
            <div class="modal-dialog">
                <!-- Modal content -->
                <div class="modal-content">
                    <!-- Modal header -->
                    <div class="modal-header">
                        <h5 class="modal-title" id="activityModalLabel">Add Activity</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="background-color:rgba(255,255,255, .1); border:none"><sup style="font-size:15px">x</sup></button>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                        <!-- Form for adding activity -->
                        <form id="activityForm" action="add_activity.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $contactID; ?>">
                            <!-- <table class="table">
                                    <tr>
                                        <td>Activity Name:</td>
                                        <td><textarea class="form-control" id="actName" name="actName" required></textarea></td>
                                    </tr>
                                    <tr>
                                        <td>Date:</td>
                                        <td><input type="date" class="form-control" id="datee" name="datee" required></td>
                                    </tr>
                                    <tr>
                                        <td>Description:</td>
                                        <td><textarea class="form-control" id="descrip" name="descrip" rows="3" required></textarea></td>
                                    </tr>
                                </table> -->

                            <div class="mb-3">
                                <label for="actName" class="form-label">Activity Name</label>
                                <input type="text" class="form-control" id="actName" name="actName" required>
                            </div>

                            <div class="mb-3">
                                <label for="datee" class="form-label">Date</label>
                                <input type="date" class="form-control" id="datee" name="datee" required>
                            </div>

                            <div class="mb-3">
                                <label for="descrip" class="form-label">Description</label>
                                <textarea class="form-control" id="descrip" name="descrip" rows="3" required></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->

        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>



    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Moment.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <!-- Tempus Dominus Bootstrap 4 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>


    <?php
    if (isset($_GET['status'])) {
        $status = $_GET['status'];
        $contactId = isset($_GET['id']) ? $_GET['id'] : ''; // Ensure $contactId is defined
        echo "
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '" . $status . "'
                }).then(function(){
                    window.location.href = 'contact_details.php?id=" . $contactId . "';       
                })
            </script>";
    }
    ?>


    <script>
        let capitalizeFirstLetter = (input) => {
            // Get the current value of the input field
            let value = input.value;

            // Capitalize the first letter if it's a letter
            if (value.length > 0 && /[a-z]/i.test(value[0])) {
                input.value = value.charAt(0).toUpperCase() + value.slice(1);
            }
        }

        $(document).ready(function() {
            $('.dropdown-input').on('input', function() {
                var filter = $(this).val().toUpperCase();
                var dropdownList = $(this).siblings('.dropdown-list');
                var options = dropdownList.find('li');
                options.each(function() {
                    var textValue = $(this).text().toUpperCase();
                    if (textValue.indexOf(filter) > -1) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });

            $('.dropdown-input').focus(function() {
                $(this).siblings('.dropdown-list').slideDown();
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('.custom-dropdown').length) {
                    $('.dropdown-list').slideUp();
                }
            });

            $('.dropdown-list li').click(function(e) {
                e.stopPropagation();
                let selectedOption = $(this).text();
                $(this).closest('.custom-dropdown').find('.dropdown-input').val(selectedOption);
                $('.dropdown-list').slideUp();
            });

            $('.dropdown-icon').click(function() {
                $(this).closest('.custom-dropdown').find('.dropdown-list').toggle();
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('.custom-dropdown').length) {
                    $('.dropdown-list').hide();
                }
            });

            $('.dropdown-list li').click(function(e) {
                e.stopPropagation();
                let selectedOption = $(this).text();
                $(this).closest('.custom-dropdown').find('.dropdown-input').val(selectedOption);
                $('.dropdown-list').hide();
            });
        });

        let showCloseButton = (client) => {
            let closeButton = document.getElementById('closeButton');
            closeButton.style.display = 'inline';

            let dropdownButton = document.getElementById('dropdownMenuButton');
            dropdownButton.textContent = client;

            // Hide all rows initially
            let dealRows = document.querySelectorAll('tbody tr');
            dealRows.forEach(row => row.style.display = 'none');

            // Show rows corresponding to the selected client
            let selectedRows = document.querySelectorAll('.' + client.toLowerCase().replace(/\s+/g, '-'));
            selectedRows.forEach(row => row.style.display = 'table-row');

            // Add event listener to the close button
            closeButton.addEventListener('click', function() {
                closeButton.style.display = 'none';
                dropdownButton.textContent = 'List of Clients';

                // Show all rows when the "x" button is clicked
                dealRows.forEach(row => row.style.display = 'table-row');
            });
        }




        $(document).ready(function() {
            $('#datetimepicker').datetimepicker({
                format: 'MMMM D, YYYY'
            });
        });
    </script>

        <!-- ayaw ma show -->
    <!-- <script>
    $(document).on("click", ".view-button", function() {
    // Retrieve the client_ID from the data attribute
    var clientId = $(this).data('client-id');

    // Hide all rows initially
    $("#viewDetailsModal tbody tr").hide();

    // Show only the row with the matching client ID
    $("#viewDetailsModal tbody tr").filter(function() {
        return $(this).find("td:last").text().trim() === clientId;
    }).show();
});

    </script> -->

</body>

</html>